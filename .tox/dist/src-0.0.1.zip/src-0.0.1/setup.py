from setuptools import setup, find_packages

setup(
    name = "src",
    version = "0.0.1",
    Description = "its a wine Q package",
    author = "Gautam",
    packages = find_packages(),
    license = "MIT"
)